package com.rahat.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.rahat.ai.MainViewModel

// ------------------------------------------------------------------ Permission Center

@Composable
private fun PermCard(title: String, desc: String, granted: Boolean, buttons: @Composable () -> Unit) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(
                if (granted) tr("✓ চালু", "✓ Granted") else tr("✗ বন্ধ", "✗ Not granted"),
                color = if (granted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(desc, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        buttons()
    }
}

@Composable
fun PermissionScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val mic = remember(tick, refresh) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }
    val notif = remember(tick, refresh) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val a11y = remember(tick) { isAccessibilityEnabled(ctx) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    Page(title = tr("পারমিশন সেন্টার", "Permission Center"), nav = nav) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PermCard(
                tr("ইন্টারনেট", "Internet"),
                tr("AI সার্ভারের সাথে কথা বলতে লাগে। অ্যান্ড্রয়েড এটি স্বয়ংক্রিয়ভাবে দেয়।", "Needed to talk to the AI server. Android grants it automatically."),
                true,
            ) {}
            PermCard(
                tr("মাইক্রোফোন", "Microphone"),
                tr("শুধু ভয়েস কমান্ডের জন্য, আপনি মাইকে চাপ দিলে।", "Only for voice commands, when you tap the mic."),
                mic,
            ) {
                if (!mic) Button(onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text(tr("অনুমতি দিন", "Allow")) }
            }
            PermCard(
                tr("নোটিফিকেশন", "Notifications"),
                tr("কাজ শেষ হলে জানাতে।", "To tell you when a task finishes."),
                notif,
            ) {
                if (!notif && Build.VERSION.SDK_INT >= 33) {
                    Button(onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text(tr("অনুমতি দিন", "Allow")) }
                }
            }
            PermCard(
                tr("Accessibility সার্ভিস", "Accessibility service"),
                tr(
                    "স্ক্রিন পড়া এবং ট্যাপ/টাইপ/স্ক্রল করার জন্য। এটাই অটোমেশনের মূল। এটি কখনো পাসওয়ার্ড ফিল্ড পড়ে না, আর কাজ চলার সময় STOP বাটন ও কনফার্ম বক্স দেখায় (আলাদা Overlay পারমিশন লাগে না)।",
                    "Lets me read the screen and tap/type/scroll. This is the core of automation. It never reads password fields and shows a STOP button and confirm box while working (no separate Overlay permission needed).",
                ),
                a11y,
            ) {
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                    Text(tr("Accessibility সেটিংস খুলুন", "Open Accessibility settings"))
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    tr(
                        "টিপ: APK সরাসরি ইনস্টল করলে অ্যান্ড্রয়েড 13+ এ সেটিংস ধূসর থাকতে পারে। তখন App info খুলে ⋮ মেনু থেকে \"Allow restricted settings\" দিন, তারপর আবার চেষ্টা করুন।",
                        "Tip: on Android 13+ a sideloaded app's setting may be greyed out. Open App info, use the ⋮ menu → \"Allow restricted settings\", then try again.",
                    ),
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }) { Text(tr("App info খুলুন", "Open App info")) }
            }
            SectionCard {
                Text(tr("এই অ্যাপে নেই", "Not included"), fontWeight = FontWeight.Bold)
                Text(
                    tr(
                        "স্ক্রিনশট/MediaProjection, ক্যামেরা ও ব্যাকগ্রাউন্ড ফোরগ্রাউন্ড সার্ভিস এই সংস্করণে বানানো হয়নি, তাই এগুলোর পারমিশনও চাওয়া হয় না।",
                        "Screenshots/MediaProjection, camera and a foreground service are not built in this version, so no permissions are requested for them.",
                    ),
                )
            }
        }
    }
}

// ------------------------------------------------------------------ AI Settings

private data class Preset(val name: String, val url: String, val model: String)

private val presets = listOf(
    Preset("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
    Preset("OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"),
    Preset("Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
    Preset("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"),
)

@Composable
fun AiSettingsScreen(vm: MainViewModel, nav: NavController) {
    val s by vm.settings.collectAsState()
    val test by vm.testResult.collectAsState()
    var url by remember { mutableStateOf(s.baseUrl) }
    var model by remember { mutableStateOf(s.model) }
    var key by remember { mutableStateOf(s.apiKey) }
    var show by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    fun save() {
        vm.settingsStore.update { it.copy(baseUrl = url.trim(), model = model.trim(), apiKey = key.trim()) }
        saved = true
    }

    Page(title = tr("AI সেটিংস", "AI Settings"), nav = nav) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(tr("প্রোভাইডার বেছে নিন (OpenAI-সামঞ্জস্যপূর্ণ):", "Pick a provider (OpenAI-compatible):"))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { p ->
                    AssistChip(onClick = { url = p.url; model = p.model; saved = false }, label = { Text(p.name) })
                }
            }
            OutlinedTextField(value = url, onValueChange = { url = it; saved = false }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = model, onValueChange = { model = it; saved = false }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; saved = false },
                label = { Text("API key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = show, onCheckedChange = { show = it })
                Text("  " + tr("কী দেখান", "Show key"))
            }
            Text(
                tr("কী শুধু এনক্রিপ্টেড স্টোরেজে এই ফোনেই থাকে।", "The key is kept only in encrypted storage on this phone."),
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { save() }) { Text(tr("সেভ", "Save")) }
                OutlinedButton(onClick = { save(); vm.testConnection() }) { Text(tr("কানেকশন টেস্ট", "Test connection")) }
            }
            if (saved) Text(tr("সেভ হয়েছে ✓", "Saved ✓"))
            if (test.isNotBlank()) Text(test)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = s.memory, onCheckedChange = { v -> vm.settingsStore.update { it.copy(memory = v) } })
                Text("  " + tr("কথোপকথনের স্মৃতি (শেষ ২০টি বার্তা AI-কে পাঠানো হবে)", "Conversation memory (last 20 messages sent to the AI)"))
            }
        }
    }
}

// ------------------------------------------------------------------ General Settings

@Composable
fun GeneralSettingsScreen(vm: MainViewModel, nav: NavController) {
    val s by vm.settings.collectAsState()
    var name by remember { mutableStateOf(s.appName) }
    Page(title = tr("সেটিংস", "Settings"), nav = nav) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; vm.settingsStore.update { st -> st.copy(appName = it) } },
                label = { Text(tr("অ্যাসিস্ট্যান্টের নাম (অ্যাপের ভেতরে)", "Assistant name (inside the app)")) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
            Text(tr("ভাষা", "Language"), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = s.lang == "bn", onClick = { vm.settingsStore.update { it.copy(lang = "bn") } }, label = { Text("বাংলা") })
                FilterChip(selected = s.lang == "en", onClick = { vm.settingsStore.update { it.copy(lang = "en") } }, label = { Text("English") })
            }
            Text(tr("থিম", "Theme"), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to tr("সিস্টেম", "System"), "dark" to tr("ডার্ক", "Dark"), "light" to tr("লাইট", "Light")).forEach { (k, label) ->
                    FilterChip(selected = s.theme == k, onClick = { vm.settingsStore.update { it.copy(theme = k) } }, label = { Text(label) })
                }
            }
            Text(tr("অ্যাকসেন্ট রং", "Accent color"), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(c)
                            .then(if (s.accent == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                            .clickable { vm.settingsStore.update { it.copy(accent = i) } },
                    )
                }
            }
            OutlinedButton(onClick = { vm.clearChat() }) { Text(tr("চ্যাট মুছুন", "Clear chat")) }
            OutlinedButton(onClick = { vm.clearTasks() }) { Text(tr("টাস্ক হিস্ট্রি মুছুন", "Clear task history")) }
            OutlinedButton(onClick = {
                vm.settingsStore.update { it.copy(onboarded = false) }
                nav.navigate("onboarding")
            }) { Text(tr("ইন্ট্রো আবার দেখুন", "Show intro again")) }
            Text(
                tr(
                    "দ্রষ্টব্য: হোম স্ক্রিনের আইকনের নাম অ্যান্ড্রয়েডে বদলানো যায় না; এখানকার নাম শুধু অ্যাপের ভেতরে দেখায়।",
                    "Note: Android doesn't allow changing the launcher label at runtime; this name only appears inside the app.",
                ),
                style = MaterialTheme.typography.bodySmall,
            )
            Text("Rahat-AI v1.0.0 • com.rahat.ai", style = MaterialTheme.typography.bodySmall)
        }
    }
}
