package com.rahat.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import com.rahat.ai.data.SettingsState

val LocalLang = compositionLocalOf { "bn" }

/** Tiny bilingual helper: tr("বাংলা", "English"). */
@Composable
fun tr(bn: String, en: String): String = if (LocalLang.current == "bn") bn else en

val Accents: List<Color> = listOf(
    Color(0xFF6C63FF), Color(0xFF00BFA5), Color(0xFFFF6D00), Color(0xFFE91E63), Color(0xFF2979FF),
)

@Composable
fun RahatTheme(s: SettingsState, content: @Composable () -> Unit) {
    val dark = when (s.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val accent = Accents[s.accent.coerceIn(0, Accents.lastIndex)]
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            secondary = accent.copy(alpha = 0.8f),
            background = Color(0xFF0B0D17),
            surface = Color(0xFF141726),
            surfaceVariant = Color(0xFF1E2236),
            onBackground = Color(0xFFE8EAF6),
            onSurface = Color(0xFFE8EAF6),
            onSurfaceVariant = Color(0xFFC5C9E0),
        )
    } else {
        lightColorScheme(
            primary = accent,
            secondary = accent.copy(alpha = 0.8f),
            background = Color(0xFFF5F6FC),
            surface = Color.White,
            surfaceVariant = Color(0xFFE9EBF7),
        )
    }
    CompositionLocalProvider(LocalLang provides s.lang) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
