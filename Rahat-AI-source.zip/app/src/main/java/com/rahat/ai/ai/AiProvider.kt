package com.rahat.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMsg(val role: String, val content: String)

/** Extensible AI engine: implement this to add another provider. */
interface AiProvider {
    suspend fun chat(messages: List<ChatMsg>, onToken: (String) -> Unit = {}): Result<String>
}

/** Works with any OpenAI-compatible /chat/completions endpoint (streaming via SSE). */
class OpenAiCompatProvider(
    private val baseUrl: String,
    private val apiKey: String,
    private val model: String,
) : AiProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    override suspend fun chat(messages: List<ChatMsg>, onToken: (String) -> Unit): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(apiKey.isNotBlank()) { "API key সেট করা নেই / API key is not set (AI Settings)" }
                val arr = JSONArray()
                messages.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
                val body = JSONObject()
                    .put("model", model)
                    .put("messages", arr)
                    .put("stream", true)
                    .toString()
                val req = Request.Builder()
                    .url(baseUrl.trimEnd('/') + "/chat/completions")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        error("HTTP ${resp.code}: ${resp.body?.string()?.take(300)}")
                    }
                    val src = resp.body!!.source()
                    val sb = StringBuilder()
                    while (!src.exhausted()) {
                        currentCoroutineContext().ensureActive()
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.removePrefix("data:").trim()
                        if (data == "[DONE]") break
                        val delta = JSONObject(data).optJSONArray("choices")
                            ?.optJSONObject(0)?.optJSONObject("delta")
                        val piece = if (delta == null || delta.isNull("content")) "" else delta.optString("content", "")
                        if (piece.isNotEmpty()) {
                            sb.append(piece)
                            onToken(piece)
                        }
                    }
                    sb.toString()
                }
            }
        }
}
