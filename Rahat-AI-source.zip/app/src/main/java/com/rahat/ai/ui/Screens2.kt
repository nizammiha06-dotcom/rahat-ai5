package com.rahat.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.rahat.ai.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ Screen Understanding

@Composable
fun ScreenUnderstandingScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { isAccessibilityEnabled(ctx) }
    val text by vm.screenText.collectAsState()
    val analysis by vm.screenAnalysis.collectAsState()
    val capturing by vm.capturing.collectAsState()
    Page(title = tr("স্ক্রিন বোঝা", "Screen Understanding"), nav = nav) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard {
                Text(
                    tr(
                        "Accessibility দিয়ে স্ক্রিনের লেখা, বাটন, মেনু ও টেক্সট ফিল্ড পড়া হয়। এখন স্ক্রিনশট/ছবি বিশ্লেষণ নেই — শুধু UI-এর টেক্সট ও কাঠামো।",
                        "Uses Accessibility to read on-screen text, buttons, menus and text fields. Screenshot/image analysis is not included — only UI text and structure.",
                    ),
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    tr(
                        "ব্যবহার: \"ক্যাপচার\" চাপুন, তারপর ৫ সেকেন্ডের মধ্যে অন্য অ্যাপে যান। ফিরে এলে ফলাফল দেখবেন।",
                        "Tap Capture, then switch to another app within 5 seconds. Come back to see the result.",
                    ),
                )
                if (!a11y) Text(tr("⚠ আগে Permission Center থেকে Accessibility চালু করুন।", "⚠ Turn on Accessibility in Permission Center first."), color = MaterialTheme.colorScheme.error)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.captureScreen(5000) }, enabled = !capturing) {
                    Text(if (capturing) tr("ক্যাপচার হচ্ছে…", "Capturing…") else tr("৫ সেকেন্ডে ক্যাপচার", "Capture in 5s"))
                }
                Button(onClick = { vm.analyzeScreen() }, enabled = text.isNotBlank()) { Text(tr("AI দিয়ে বিশ্লেষণ", "Analyze with AI")) }
            }
            if (text.isNotBlank()) {
                SectionCard {
                    Text(tr("স্ক্রিনের তথ্য", "Screen data"), fontWeight = FontWeight.Bold)
                    Text(text, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (analysis.isNotBlank()) {
                SectionCard {
                    Text(tr("AI বিশ্লেষণ", "AI analysis"), fontWeight = FontWeight.Bold)
                    Text(analysis)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Automation Center

@Composable
fun AutomationScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { isAccessibilityEnabled(ctx) }
    val running by vm.runner.running.collectAsState()
    val log by vm.runner.log.collectAsState()
    var goal by remember { mutableStateOf("") }
    val examples = listOf(
        tr("Settings অ্যাপ খুলুন", "Open the Settings app"),
        tr("Chrome খুলে আজকের আবহাওয়া সার্চ করুন", "Open Chrome and search today's weather"),
        tr("Clock অ্যাপ খুলুন", "Open the Clock app"),
    )
    Page(title = tr("অটোমেশন সেন্টার", "Automation Center"), nav = nav) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard {
                Text(
                    tr(
                        "AI স্ক্রিন পড়ে একেকটি ধাপ করে কাজ করে (সর্বোচ্চ ১৫ ধাপ)। পাঠানো, কেনা, মোছা ইত্যাদি কাজের আগে আপনাকে জিজ্ঞেস করা হবে। কাজ চলার সময় স্ক্রিনে লাল STOP বাটন থাকবে।",
                        "The AI reads the screen and works one step at a time (max 15 steps). It asks before sending, buying, deleting, etc. A red STOP button stays on screen while it works.",
                    ),
                )
                if (!a11y) Text(tr("⚠ Accessibility চালু নেই।", "⚠ Accessibility is off."), color = MaterialTheme.colorScheme.error)
            }
            OutlinedTextField(
                value = goal,
                onValueChange = { goal = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(tr("কী করতে হবে?", "What should I do?")) },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.runAgent(goal.trim()) }, enabled = goal.isNotBlank() && !running && a11y) {
                    Text(tr("চালান", "Run"))
                }
                Button(onClick = { vm.stopAll() }, enabled = running) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Text(tr(" থামান", " Stop"))
                }
            }
            examples.forEach { ex -> AssistChip(onClick = { goal = ex }, label = { Text(ex) }) }
            if (log.isNotEmpty()) {
                SectionCard {
                    Text(if (running) tr("লাইভ লগ", "Live log") else tr("শেষ রান", "Last run"), fontWeight = FontWeight.Bold)
                    log.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Task History

@Composable
fun HistoryScreen(vm: MainViewModel, nav: NavController) {
    val tasks by vm.tasks.collectAsState()
    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    Page(
        title = tr("টাস্ক হিস্ট্রি", "Task History"),
        nav = nav,
        actions = { IconButton(onClick = { vm.clearTasks() }) { Icon(Icons.Filled.Delete, contentDescription = null) } },
    ) { pad ->
        if (tasks.isEmpty()) {
            Column(Modifier.padding(pad).fillMaxSize().padding(24.dp)) { Text(tr("এখনো কোনো টাস্ক নেই।", "No tasks yet.")) }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks, key = { it.id }) { t ->
                    SectionCard {
                        Text(t.command, fontWeight = FontWeight.Bold)
                        Text("${t.status} • ${fmt.format(Date(t.ts))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        if (t.log.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(t.log, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
