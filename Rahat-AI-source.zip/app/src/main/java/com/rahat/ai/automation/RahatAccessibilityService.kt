package com.rahat.ai.automation

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Reads the visible screen and performs user-authorised actions.
 * Also draws two overlays (no extra permission needed): a STOP button and a confirmation box.
 */
class RahatAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: RahatAccessibilityService? = null
        private const val MAX_NODES = 90
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var stopView: View? = null
    private var confirmView: View? = null
    private var cache: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideOverlays()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideOverlays()
        instance = null
        super.onDestroy()
    }

    // ---------- Reading the screen ----------

    /** Returns a numbered text description of the visible UI. Password fields are never read. */
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "(screen not readable right now)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder("APP: ${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || list.size >= MAX_NODES || !n.isVisibleToUser) return
            val secret = n.isPassword
            val text = if (secret) "" else (n.text?.toString() ?: "").take(80)
            val desc = (n.contentDescription?.toString() ?: "").take(80)
            val interesting = text.isNotBlank() || desc.isNotBlank() || n.isClickable ||
                n.isEditable || n.isScrollable
            if (interesting) {
                val idx = list.size
                list.add(n)
                sb.append("[").append(idx).append("] ")
                    .append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                if (text.isNotBlank()) sb.append(" \"").append(text).append("\"")
                if (desc.isNotBlank() && desc != text) sb.append(" (desc: ").append(desc).append(")")
                if (secret) sb.append(" [password field - hidden]")
                if (n.isClickable) sb.append(" clickable")
                if (n.isEditable) sb.append(" editable")
                if (n.isScrollable) sb.append(" scrollable")
                if (n.isChecked) sb.append(" checked")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }

        walk(root)
        cache = list
        return sb.toString()
    }

    fun labelOf(index: Int): String {
        val n = cache.getOrNull(index) ?: return ""
        return n.text?.toString() ?: n.contentDescription?.toString() ?: ""
    }

    // ---------- Actions ----------

    private fun clickNode(start: AccessibilityNodeInfo?): Boolean {
        var cur = start
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            hops++
        }
        return false
    }

    fun clickIndex(index: Int): Boolean = clickNode(cache.getOrNull(index))

    fun clickText(text: String): Boolean {
        if (text.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val hit = root.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser }
        return clickNode(hit)
    }

    fun typeInto(index: Int, text: String): Boolean {
        var target: AccessibilityNodeInfo? = if (index >= 0) cache.getOrNull(index) else null
        if (target == null || !target.isEditable) {
            target = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        }
        if (target == null || !target.isEditable) {
            target = cache.firstOrNull { it.isEditable }
        }
        if (target == null) return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(direction: String): Boolean {
        val node = cache.firstOrNull { it.isScrollable } ?: return false
        val action = if (direction.equals("up", true)) {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return node.performAction(action)
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    // ---------- Overlays: STOP button + confirmation ----------

    private fun overlayParams(w: Int, gravity: Int, yOffset: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            this.gravity = gravity
            y = yOffset
        }

    fun showStop(onStop: () -> Unit) {
        main.post {
            if (stopView != null) return@post
            val b = Button(this).apply {
                text = "■ STOP"
                setTextColor(Color.WHITE)
                setBackgroundColor(0xE6D32F2F.toInt())
                setOnClickListener { onStop() }
            }
            try {
                wm?.addView(b, overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END, 220))
                stopView = b
            } catch (e: Exception) {
            }
        }
    }

    fun showConfirm(message: String, bn: Boolean, onResult: (Boolean) -> Unit) {
        main.post {
            removeConfirm()
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(40, 40, 40, 40)
                setBackgroundColor(0xF2222222.toInt())
            }
            val tv = TextView(this).apply {
                text = message
                setTextColor(Color.WHITE)
                textSize = 17f
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val deny = Button(this).apply {
                text = if (bn) "না" else "Deny"
                setOnClickListener { removeConfirm(); onResult(false) }
            }
            val allow = Button(this).apply {
                text = if (bn) "হ্যাঁ, করুন" else "Allow"
                setOnClickListener { removeConfirm(); onResult(true) }
            }
            row.addView(deny)
            row.addView(allow)
            box.addView(tv)
            box.addView(row)
            try {
                wm?.addView(box, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, Gravity.BOTTOM, 120))
                confirmView = box
            } catch (e: Exception) {
                onResult(false)
            }
        }
    }

    fun hideConfirm() {
        main.post { removeConfirm() }
    }

    private fun removeConfirm() {
        confirmView?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        confirmView = null
    }

    fun hideOverlays() {
        main.post {
            removeConfirm()
            stopView?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
            stopView = null
        }
    }
}
