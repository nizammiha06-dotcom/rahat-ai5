package com.rahat.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class SettingsState(
    val appName: String = "Rahat-AI",
    val baseUrl: String = "https://api.openai.com/v1",
    val model: String = "gpt-4o-mini",
    val apiKey: String = "",
    val lang: String = "bn",
    val theme: String = "system",
    val accent: Int = 0,
    val memory: Boolean = true,
    val onboarded: Boolean = false,
)

/** Normal settings live in plain prefs; the API key lives only in EncryptedSharedPreferences. */
class SettingsStore(ctx: Context) {
    private val plain: SharedPreferences =
        ctx.getSharedPreferences("rahat_prefs", Context.MODE_PRIVATE)

    private val secure: SharedPreferences? = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "rahat_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        null
    }

    // Used only if encrypted storage is unavailable: the key is kept in memory, never on disk.
    private var memoryKey = ""

    private val _state = MutableStateFlow(load())
    val state: StateFlow<SettingsState> = _state

    private fun readKey(): String = secure?.getString("api_key", "") ?: memoryKey

    private fun load(): SettingsState {
        val d = SettingsState()
        return SettingsState(
            appName = plain.getString("app_name", d.appName) ?: d.appName,
            baseUrl = plain.getString("base_url", d.baseUrl) ?: d.baseUrl,
            model = plain.getString("model", d.model) ?: d.model,
            apiKey = readKey(),
            lang = plain.getString("lang", d.lang) ?: d.lang,
            theme = plain.getString("theme", d.theme) ?: d.theme,
            accent = plain.getInt("accent", d.accent),
            memory = plain.getBoolean("memory", d.memory),
            onboarded = plain.getBoolean("onboarded", d.onboarded),
        )
    }

    fun update(change: (SettingsState) -> SettingsState) {
        val n = change(_state.value)
        plain.edit()
            .putString("app_name", n.appName)
            .putString("base_url", n.baseUrl)
            .putString("model", n.model)
            .putString("lang", n.lang)
            .putString("theme", n.theme)
            .putInt("accent", n.accent)
            .putBoolean("memory", n.memory)
            .putBoolean("onboarded", n.onboarded)
            .apply()
        if (secure != null) secure.edit().putString("api_key", n.apiKey).apply() else memoryKey = n.apiKey
        _state.value = n
    }
}
