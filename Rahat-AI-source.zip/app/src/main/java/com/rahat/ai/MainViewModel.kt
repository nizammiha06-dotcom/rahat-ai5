package com.rahat.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rahat.ai.agent.AgentRunner
import com.rahat.ai.ai.AiProvider
import com.rahat.ai.ai.ChatMsg
import com.rahat.ai.ai.OpenAiCompatProvider
import com.rahat.ai.automation.RahatAccessibilityService
import com.rahat.ai.data.AppDb
import com.rahat.ai.data.MessageEntity
import com.rahat.ai.data.SettingsState
import com.rahat.ai.data.SettingsStore
import com.rahat.ai.voice.VoiceController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val settingsStore = SettingsStore(app)
    val settings: StateFlow<SettingsState> = settingsStore.state

    private val dao = AppDb.get(app).dao()
    val messages = dao.messages().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val streaming = MutableStateFlow("")
    val busy = MutableStateFlow(false)
    val agentMode = MutableStateFlow(false)
    val runner = AgentRunner(app, dao)
    val voice = VoiceController(app)

    val handsFree = MutableStateFlow(false)
    val voiceHeard = MutableStateFlow("")
    val voiceReply = MutableStateFlow("")
    val voiceStatus = MutableStateFlow("")

    val screenText = MutableStateFlow("")
    val screenAnalysis = MutableStateFlow("")
    val capturing = MutableStateFlow(false)
    val testResult = MutableStateFlow("")

    private var chatJob: Job? = null

    private fun provider(): AiProvider {
        val s = settings.value
        return OpenAiCompatProvider(s.baseUrl, s.apiKey, s.model)
    }

    private fun chatSystem(s: SettingsState) =
        "You are ${s.appName}, a friendly personal assistant app on the user's Android phone. " +
            "Always reply in the language the user writes in (Bengali or English). Be concise and helpful. " +
            "In this mode you cannot operate the phone; if the user wants you to open apps, tap, type or " +
            "navigate, tell them to switch on Agent mode."

    // ---------- Chat ----------

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy.value || runner.running.value) return
        if (agentMode.value) runAgent(t) else chatJob = viewModelScope.launch { chatTurn(t) }
    }

    private suspend fun chatTurn(text: String): String? {
        busy.value = true
        streaming.value = ""
        dao.insert(MessageEntity(role = "user", content = text))
        val s = settings.value
        val ctx = mutableListOf(ChatMsg("system", chatSystem(s)))
        if (s.memory) {
            dao.recent(20).reversed().filter { it.role != "error" }
                .forEach { ctx.add(ChatMsg(it.role, it.content)) }
        } else {
            ctx.add(ChatMsg("user", text))
        }
        var reply: String? = null
        var error: String? = null
        try {
            val r = provider().chat(ctx) { streaming.value += it }
            r.onSuccess { reply = it }.onFailure { error = it.message ?: "error" }
        } catch (e: CancellationException) {
            reply = streaming.value.takeIf { it.isNotBlank() }?.plus(" ⏹")
            throw e
        } finally {
            withContext(NonCancellable) {
                reply?.let { dao.insert(MessageEntity(role = "assistant", content = it)) }
                error?.let { dao.insert(MessageEntity(role = "error", content = it)) }
                streaming.value = ""
                busy.value = false
            }
        }
        return reply
    }

    fun clearChat() {
        viewModelScope.launch { dao.clearMessages() }
    }

    fun clearTasks() {
        viewModelScope.launch { dao.clearTasks() }
    }

    // ---------- Agent ----------

    fun runAgent(goal: String, speakResult: Boolean = false) {
        if (runner.running.value) return
        viewModelScope.launch { dao.insert(MessageEntity(role = "user", content = goal)) }
        val bn = settings.value.lang == "bn"
        runner.start(viewModelScope, goal, provider(), bn) { msg ->
            viewModelScope.launch {
                dao.insert(MessageEntity(role = "assistant", content = msg))
                voiceReply.value = msg
                if (speakResult) voice.speak(msg, bn) { if (handsFree.value) voiceListen() }
            }
        }
    }

    fun stopAll() {
        handsFree.value = false
        chatJob?.cancel()
        runner.stop()
        voice.stopSpeaking()
        voice.stopListening()
    }

    // ---------- Voice ----------

    fun voiceListen() {
        voiceStatus.value = ""
        voice.startListening(
            settings.value.lang == "bn",
            onText = { handleVoiceText(it) },
            onFail = { voiceStatus.value = it },
        )
    }

    fun voiceStop() = voice.stopListening()

    private fun handleVoiceText(t: String) {
        voiceHeard.value = t
        voiceReply.value = ""
        val bn = settings.value.lang == "bn"
        if (agentMode.value) {
            runAgent(t, speakResult = true)
        } else {
            chatJob = viewModelScope.launch {
                val reply = chatTurn(t)
                if (reply != null) {
                    voiceReply.value = reply
                    voice.speak(reply, bn) { if (handsFree.value) voiceListen() }
                }
            }
        }
    }

    // ---------- Screen understanding ----------

    fun captureScreen(delayMs: Long) {
        viewModelScope.launch {
            capturing.value = true
            screenAnalysis.value = ""
            delay(delayMs)
            val svc = RahatAccessibilityService.instance
            screenText.value = svc?.snapshot()
                ?: "Accessibility service is off. Turn it on in Permission Center."
            capturing.value = false
        }
    }

    fun analyzeScreen() {
        val snap = screenText.value
        if (snap.isBlank()) return
        val bn = settings.value.lang == "bn"
        viewModelScope.launch {
            screenAnalysis.value = "…"
            val sys = "You analyse Android screens from a text dump of UI elements. Reply in " +
                (if (bn) "Bengali" else "English") + ", briefly."
            val user = "Here is the current phone screen:\n$snap\n\nDescribe: the active app, the visible " +
                "buttons/menus/text fields, and suggest sensible next actions."
            val r = provider().chat(listOf(ChatMsg("system", sys), ChatMsg("user", user)))
            screenAnalysis.value = r.getOrElse { "⚠ ${it.message}" }
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            testResult.value = "…"
            val r = provider().chat(listOf(ChatMsg("user", "Reply with the single word: OK")))
            testResult.value = r.fold({ "✅ OK" }, { "❌ ${it.message}" })
        }
    }

    override fun onCleared() {
        voice.shutdown()
        super.onCleared()
    }
}
