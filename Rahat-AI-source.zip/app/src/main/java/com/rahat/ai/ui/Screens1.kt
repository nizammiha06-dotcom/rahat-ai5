package com.rahat.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.rahat.ai.MainViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ Splash & Onboarding

@Composable
fun SplashScreen(vm: MainViewModel, nav: NavController) {
    val s by vm.settings.collectAsState()
    LaunchedEffect(Unit) {
        delay(1400)
        val next = if (vm.settings.value.onboarded) "dashboard" else "onboarding"
        nav.navigate(next) { popUpTo("splash") { inclusive = true } }
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AiOrb(active = true)
            Spacer(Modifier.height(16.dp))
            Text(
                s.appName.ifBlank { "Rahat-AI" },
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(vm: MainViewModel, nav: NavController) {
    val pages = listOf(
        tr("আপনার ব্যক্তিগত AI সহকারী", "Your personal AI assistant") to
            tr("বাংলা ও ইংরেজিতে কথা বলুন বা লিখুন। চ্যাট করুন, প্রশ্ন করুন।", "Talk or type in Bengali and English. Chat and ask anything."),
        tr("ফোন চালাতে সাহায্য করে", "Helps operate your phone") to
            tr("Agent মোডে আমি স্ক্রিন পড়ে অ্যাপ খুলতে, ট্যাপ করতে, লিখতে ও স্ক্রল করতে পারি — আপনার অনুমতিতে।", "In Agent mode I read the screen and open apps, tap, type and scroll — with your permission."),
        tr("আপনি সবসময় নিয়ন্ত্রণে", "You stay in control", ) to
            tr("সংবেদনশীল কাজে আগে জিজ্ঞেস করব। কাজ চলার সময় একটি STOP বাটন দেখা যাবে।", "I ask before sensitive actions. A STOP button is shown while I work."),
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        AiOrb()
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { i ->
            Column(Modifier.fillMaxSize().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(pages[i].first, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(pages[i].second, textAlign = TextAlign.Center)
            }
        }
        Button(
            onClick = {
                if (pager.currentPage < pages.lastIndex) {
                    scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                } else {
                    vm.settingsStore.update { it.copy(onboarded = true) }
                    nav.navigate("dashboard") { popUpTo("onboarding") { inclusive = true } }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(if (pager.currentPage < pages.lastIndex) tr("পরবর্তী", "Next") else tr("শুরু করুন", "Get started"))
        }
    }
}

// ------------------------------------------------------------------ Dashboard

private data class Tile(val icon: ImageVector, val label: String, val route: String)

@Composable
fun DashboardScreen(vm: MainViewModel, nav: NavController) {
    val s by vm.settings.collectAsState()
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { isAccessibilityEnabled(ctx) }
    val running by vm.runner.running.collectAsState()
    val speaking by vm.voice.speaking.collectAsState()
    val listening by vm.voice.listening.collectAsState()
    val tiles = listOf(
        Tile(Icons.Filled.Forum, tr("চ্যাট", "Chat"), "chat"),
        Tile(Icons.Filled.Mic, tr("ভয়েস", "Voice"), "voice"),
        Tile(Icons.Filled.Visibility, tr("স্ক্রিন বোঝা", "Screen"), "screen"),
        Tile(Icons.Filled.SmartToy, tr("অটোমেশন", "Automation"), "automation"),
        Tile(Icons.Filled.History, tr("টাস্ক হিস্ট্রি", "History"), "history"),
        Tile(Icons.Filled.AdminPanelSettings, tr("পারমিশন", "Permissions"), "permissions"),
        Tile(Icons.Filled.Psychology, tr("AI সেটিংস", "AI Settings"), "aisettings"),
        Tile(Icons.Filled.Settings, tr("সেটিংস", "Settings"), "settings"),
    )
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(s.appName.ifBlank { "Rahat-AI" }, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        AiOrb(active = running || speaking || listening, orbSize = 170.dp)
        Text(tr("আমি কীভাবে সাহায্য করতে পারি?", "How can I help you today?"), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(
                onClick = { nav.navigate("aisettings") },
                label = { Text(if (s.apiKey.isBlank()) tr("API key নেই", "No API key") else tr("API key ✓", "API key ✓")) },
            )
            AssistChip(
                onClick = { nav.navigate("permissions") },
                label = { Text(if (a11y) tr("Accessibility ✓", "Accessibility ✓") else tr("Accessibility বন্ধ", "Accessibility off")) },
            )
        }
        Spacer(Modifier.height(12.dp))
        tiles.chunked(2).forEach { rowTiles ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowTiles.forEach { t ->
                    Card(
                        modifier = Modifier.weight(1f).height(92.dp).clip(RoundedCornerShape(16.dp)).clickable { nav.navigate(t.route) },
                    ) {
                        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(t.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(6.dp))
                            Text(t.label, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                if (rowTiles.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ------------------------------------------------------------------ Chat

@Composable
private fun Bubble(role: String, text: String) {
    val cs = MaterialTheme.colorScheme
    val isUser = role == "user"
    val bg = when (role) {
        "user" -> cs.primary
        "error" -> cs.errorContainer
        else -> cs.surfaceVariant
    }
    val fg = when (role) {
        "user" -> cs.onPrimary
        "error" -> cs.onErrorContainer
        else -> cs.onSurface
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(shape = RoundedCornerShape(16.dp), color = bg, modifier = Modifier.widthIn(max = 320.dp)) {
            Text(text, color = fg, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
fun ChatScreen(vm: MainViewModel, nav: NavController) {
    val msgs by vm.messages.collectAsState()
    val streaming by vm.streaming.collectAsState()
    val busy by vm.busy.collectAsState()
    val agent by vm.agentMode.collectAsState()
    val running by vm.runner.running.collectAsState()
    val log by vm.runner.log.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size, streaming.length) {
        val n = msgs.size + (if (streaming.isNotEmpty()) 1 else 0)
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    Page(
        title = tr("চ্যাট", "Chat"),
        nav = nav,
        actions = { IconButton(onClick = { vm.clearChat() }) { Icon(Icons.Filled.Delete, contentDescription = null) } },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (msgs.isEmpty() && streaming.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        tr("কিছু লিখুন। ফোন চালাতে Agent মোড চালু করুন।", "Type something. Turn on Agent mode to operate the phone."),
                        modifier = Modifier.padding(24.dp), textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    state = listState,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(msgs, key = { it.id }) { Bubble(it.role, it.content) }
                    if (streaming.isNotEmpty()) item { Bubble("assistant", streaming) }
                }
            }
            if (running) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(tr("এজেন্ট কাজ করছে…", "Agent is working…"), fontWeight = FontWeight.Bold)
                        log.takeLast(4).forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = agent, onClick = { vm.agentMode.value = !agent }, label = { Text(tr("Agent মোড", "Agent mode")) })
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(if (agent) tr("কী করতে হবে?", "What should I do?") else tr("বার্তা লিখুন…", "Type a message…")) },
                    maxLines = 4,
                )
                IconButton(onClick = {
                    if (busy || running) vm.stopAll() else if (input.isNotBlank()) {
                        vm.send(input)
                        input = ""
                    }
                }) {
                    Icon(if (busy || running) Icons.Filled.Stop else Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Voice

@Composable
fun VoiceScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val listening by vm.voice.listening.collectAsState()
    val speaking by vm.voice.speaking.collectAsState()
    val partial by vm.voice.partial.collectAsState()
    val ttsIssue by vm.voice.ttsIssue.collectAsState()
    val heard by vm.voiceHeard.collectAsState()
    val reply by vm.voiceReply.collectAsState()
    val status by vm.voiceStatus.collectAsState()
    val hands by vm.handsFree.collectAsState()
    val agent by vm.agentMode.collectAsState()
    val running by vm.runner.running.collectAsState()
    val denied = tr("মাইক্রোফোন পারমিশন দেওয়া হয়নি", "Microphone permission was denied")
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.voiceListen() else vm.voiceStatus.value = denied
    }
    Page(title = tr("ভয়েস অ্যাসিস্ট্যান্ট", "Voice Assistant"), nav = nav) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AiOrb(active = listening || speaking || running, orbSize = 200.dp)
            Spacer(Modifier.height(8.dp))
            Text(
                when {
                    listening -> tr("শুনছি…", "Listening…")
                    speaking -> tr("বলছি…", "Speaking…")
                    running -> tr("কাজ চলছে…", "Working…")
                    else -> tr("মাইকে চাপ দিয়ে বলুন", "Tap the mic and speak")
                },
                style = MaterialTheme.typography.titleMedium,
            )
            if (partial.isNotBlank()) Text(partial, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    if (listening) vm.voiceStop()
                    else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.voiceListen()
                    else launcher.launch(Manifest.permission.RECORD_AUDIO)
                }) {
                    Icon(Icons.Filled.Mic, contentDescription = null)
                    Text(if (listening) tr(" থামান", " Stop") else tr(" বলুন", " Speak"))
                }
                Button(onClick = { vm.stopAll() }) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Text(tr(" সব বন্ধ", " Stop all"))
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = agent, onCheckedChange = { vm.agentMode.value = it })
                Text("  " + tr("Agent মোড (ফোন চালাবে)", "Agent mode (operate phone)"))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = hands, onCheckedChange = { vm.handsFree.value = it })
                Text("  " + tr("হ্যান্ডস-ফ্রি (উত্তরের পর আবার শুনবে)", "Hands-free (listen again after reply)"))
            }
            Spacer(Modifier.height(12.dp))
            if (heard.isNotBlank()) SectionCard { Text(tr("আপনি বলেছেন", "You said"), fontWeight = FontWeight.Bold); Text(heard) }
            if (reply.isNotBlank()) { Spacer(Modifier.height(8.dp)); SectionCard { Text(tr("উত্তর", "Reply"), fontWeight = FontWeight.Bold); Text(reply) } }
            if (status.isNotBlank()) Text(status, color = MaterialTheme.colorScheme.error)
            ttsIssue?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}
