package com.rahat.ai.agent

import android.Manifest
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.rahat.ai.MainActivity
import com.rahat.ai.ai.AiProvider
import com.rahat.ai.ai.ChatMsg
import com.rahat.ai.automation.RahatAccessibilityService
import com.rahat.ai.data.AppDao
import com.rahat.ai.data.TaskEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Multi-step agent: read screen -> ask the model for ONE action -> execute -> repeat. */
class AgentRunner(private val app: Context, private val dao: AppDao) {

    val running = MutableStateFlow(false)
    val log = MutableStateFlow<List<String>>(emptyList())

    private var job: Job? = null

    @Volatile
    private var stopRequested = false

    companion object {
        private const val MAX_STEPS = 15
        private const val CHANNEL = "rahat_tasks"
        private val SENSITIVE = Regex(
            "send|pay|buy|purchase|order|delete|remove|transfer|post|submit|" +
                "পাঠা|কিন|পেমেন্ট|ডিলিট|মুছ|সেন্ড|অর্ডার|ট্রান্সফার",
            RegexOption.IGNORE_CASE,
        )
        private const val SYSTEM = """You control an Android phone through an accessibility API to achieve the user's GOAL.
Each turn you receive the current screen as numbered UI elements. Reply with ONE JSON object only (no markdown):
{"thought":"short reason","action":{"type":"...", ...}}
Action types:
- open_app {"name":"App label"}
- click {"index":N}  (preferred) or {"text":"label"}
- type {"index":N (optional), "text":"..."}
- scroll {"direction":"up"|"down"}
- back, home, wait
- done {"message":"what was achieved, in the user's language"}
- ask_user {"message":"what you need from the user"}
Add "sensitive":true to the action for anything that sends a message, pays, buys, deletes, posts, or is irreversible.
Never type passwords, OTPs or payment details: use ask_user instead.
Finish with done as soon as the goal is achieved."""
    }

    fun stop() {
        stopRequested = true
        job?.cancel()
    }

    fun start(scope: CoroutineScope, goal: String, provider: AiProvider, bn: Boolean, onFinish: (String) -> Unit) {
        if (running.value) return
        running.value = true
        stopRequested = false
        job = scope.launch { run(goal, provider, bn, onFinish) }
    }

    private fun addLog(s: String) {
        log.value = log.value + s
    }

    private fun parse(reply: String): JSONObject? {
        val s = reply.indexOf('{')
        val e = reply.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return runCatching { JSONObject(reply.substring(s, e + 1)) }.getOrNull()
    }

    private suspend fun run(goal: String, provider: AiProvider, bn: Boolean, onFinish: (String) -> Unit) {
        log.value = emptyList()
        val taskId = dao.insertTask(TaskEntity(command = goal, status = "running", log = ""))
        var status = "done"
        var message = ""
        try {
            val svc = RahatAccessibilityService.instance
            if (svc == null) {
                status = "failed"
                message = if (bn) "Accessibility সার্ভিস চালু নেই। Permission Center থেকে চালু করুন।"
                else "Accessibility service is off. Turn it on in Permission Center."
            } else {
                svc.showStop { stop() }
                val history = mutableListOf<String>()
                var finished = false
                var step = 0
                while (!finished && step < MAX_STEPS) {
                    step++
                    currentCoroutineContext().ensureActive()
                    val screen = svc.snapshot()
                    val prompt = buildString {
                        appendLine("GOAL: $goal")
                        appendLine("STEP: $step/$MAX_STEPS")
                        appendLine("PREVIOUS ACTIONS:")
                        history.takeLast(8).forEach { appendLine("- $it") }
                        appendLine("CURRENT SCREEN:")
                        appendLine(screen)
                    }
                    val reply = provider.chat(
                        listOf(ChatMsg("system", SYSTEM), ChatMsg("user", prompt)),
                    ).getOrThrow()
                    val obj = parse(reply)
                    val act = obj?.optJSONObject("action")
                    if (act == null) {
                        history.add("(model reply was not valid JSON)")
                        addLog("#$step: invalid model reply")
                        continue
                    }
                    val type = act.optString("type")
                    addLog("#$step: $type ${act.optString("name")}${act.optString("text")}" +
                        (if (act.has("index")) " [${act.optInt("index")}]" else ""))

                    when (type) {
                        "done", "ask_user" -> {
                            message = act.optString("message", if (bn) "সম্পন্ন" else "Done")
                            if (type == "ask_user") status = "needs_input"
                            finished = true
                        }
                        "wait" -> delay(1500)
                        "back" -> svc.back()
                        "home" -> svc.home()
                        "scroll" -> svc.scroll(act.optString("direction", "down"))
                        "open_app" -> {
                            if (!openApp(act.optString("name"))) history.add("open_app failed: app not found")
                        }
                        "click" -> {
                            val idx = if (act.has("index")) act.optInt("index", -1) else -1
                            val label = if (idx >= 0) svc.labelOf(idx) else act.optString("text")
                            if (!confirmIfNeeded(svc, act, label, bn, true)) {
                                status = "stopped"
                                message = if (bn) "আপনি কাজটি অনুমোদন করেননি।" else "You denied the action."
                                finished = true
                            } else {
                                val ok = if (idx >= 0) svc.clickIndex(idx) else svc.clickText(label)
                                if (!ok) history.add("click failed on '$label'")
                            }
                        }
                        "type" -> {
                            val text = act.optString("text")
                            val idx = if (act.has("index")) act.optInt("index", -1) else -1
                            if (!confirmIfNeeded(svc, act, text, bn, false)) {
                                status = "stopped"
                                message = if (bn) "আপনি কাজটি অনুমোদন করেননি।" else "You denied the action."
                                finished = true
                            } else if (!svc.typeInto(idx, text)) {
                                history.add("type failed: no editable field")
                            }
                        }
                        else -> history.add("unknown action: $type")
                    }
                    history.add(act.toString().take(150))
                    if (!finished) delay(1200)
                }
                if (!finished) {
                    status = "failed"
                    message = if (bn) "ধাপের সীমা ($MAX_STEPS) শেষ, কাজটি সম্পূর্ণ হয়নি।"
                    else "Step limit ($MAX_STEPS) reached; the task was not completed."
                }
            }
        } catch (e: CancellationException) {
            status = "stopped"
        } catch (e: Exception) {
            status = if (stopRequested) "stopped" else "failed"
            message = e.message ?: "error"
        } finally {
            withContext(NonCancellable) {
                if (stopRequested) {
                    status = "stopped"
                    message = if (bn) "থামানো হয়েছে।" else "Stopped."
                }
                if (message.isBlank()) message = status
                RahatAccessibilityService.instance?.hideOverlays()
                dao.updateTask(
                    TaskEntity(
                        id = taskId, command = goal, status = status,
                        log = (log.value + "→ $message").joinToString("\n"),
                    ),
                )
                running.value = false
                notifyDone(message)
                onFinish(message)
            }
        }
    }

    private suspend fun confirmIfNeeded(
        svc: RahatAccessibilityService,
        act: JSONObject,
        label: String,
        bn: Boolean,
        useRegex: Boolean,
    ): Boolean {
        val sensitive = act.optBoolean("sensitive") || (useRegex && SENSITIVE.containsMatchIn(label))
        if (!sensitive) return true
        val msg = if (bn) "Rahat-AI এই কাজটি করতে চাইছে:\n\"$label\"\nঅনুমতি দেবেন?"
        else "Rahat-AI wants to do this:\n\"$label\"\nAllow?"
        val d = CompletableDeferred<Boolean>()
        svc.showConfirm(msg, bn) { d.complete(it) }
        try {
            return d.await()
        } finally {
            svc.hideConfirm()
        }
    }

    private fun openApp(name: String): Boolean {
        val q = name.trim().lowercase()
        if (q.isBlank()) return false
        val pm = app.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase() == q }
        val launch = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) } ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ctx: Context = RahatAccessibilityService.instance ?: app
        return try {
            ctx.startActivity(launch)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun notifyDone(text: String) {
        try {
            val nm = NotificationManagerCompat.from(app)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Rahat tasks", android.app.NotificationManager.IMPORTANCE_DEFAULT),
            )
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return
            val pi = PendingIntent.getActivity(
                app, 0,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val n = NotificationCompat.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Rahat-AI")
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(1001, n)
        } catch (e: Exception) {
        }
    }
}
