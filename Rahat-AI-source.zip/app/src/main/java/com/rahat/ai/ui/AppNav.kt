package com.rahat.ai.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rahat.ai.MainViewModel

@Composable
fun AppNav(vm: MainViewModel) {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = "splash",
        enterTransition = { fadeIn(tween(300)) },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(300)) },
        popExitTransition = { fadeOut(tween(200)) },
    ) {
        composable("splash") { SplashScreen(vm, nav) }
        composable("onboarding") { OnboardingScreen(vm, nav) }
        composable("dashboard") { DashboardScreen(vm, nav) }
        composable("chat") { ChatScreen(vm, nav) }
        composable("voice") { VoiceScreen(vm, nav) }
        composable("screen") { ScreenUnderstandingScreen(vm, nav) }
        composable("automation") { AutomationScreen(vm, nav) }
        composable("history") { HistoryScreen(vm, nav) }
        composable("permissions") { PermissionScreen(vm, nav) }
        composable("aisettings") { AiSettingsScreen(vm, nav) }
        composable("settings") { GeneralSettingsScreen(vm, nav) }
    }
}
