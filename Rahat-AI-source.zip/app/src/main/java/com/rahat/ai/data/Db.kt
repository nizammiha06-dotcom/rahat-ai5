package com.rahat.ai.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val ts: Long = System.currentTimeMillis(),
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val command: String,
    val status: String,
    val log: String,
    val ts: Long = System.currentTimeMillis(),
)

@Dao
interface AppDao {
    @Query("SELECT * FROM messages ORDER BY id ASC")
    fun messages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :n")
    suspend fun recent(n: Int): List<MessageEntity>

    @Insert
    suspend fun insert(m: MessageEntity): Long

    @Query("DELETE FROM messages")
    suspend fun clearMessages()

    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun tasks(): Flow<List<TaskEntity>>

    @Insert
    suspend fun insertTask(t: TaskEntity): Long

    @Update
    suspend fun updateTask(t: TaskEntity)

    @Query("DELETE FROM tasks")
    suspend fun clearTasks()
}

@Database(entities = [MessageEntity::class, TaskEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile
        private var inst: AppDb? = null

        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "rahat.db")
                .build().also { inst = it }
        }
    }
}
