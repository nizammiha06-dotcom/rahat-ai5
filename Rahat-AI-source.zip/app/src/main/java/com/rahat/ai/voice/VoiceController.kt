package com.rahat.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/** Speech recognition (bn-BD / en-US) and text-to-speech. Uses the phone's installed engines. */
class VoiceController(private val ctx: Context) {

    val listening = MutableStateFlow(false)
    val speaking = MutableStateFlow(false)
    val partial = MutableStateFlow("")
    val ttsIssue = MutableStateFlow<String?>(null)

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(ctx) { status -> ttsReady = status == TextToSpeech.SUCCESS }
    }

    private fun destroyRecognizer() {
        recognizer?.destroy()
        recognizer = null
        listening.value = false
    }

    fun startListening(bn: Boolean, onText: (String) -> Unit, onFail: (String) -> Unit) {
        main.post {
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                onFail("Speech recognition is not available on this phone")
                return@post
            }
            destroyRecognizer()
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening.value = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    listening.value = false
                    partial.value = ""
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কিছু শোনা যায়নি / Nothing heard"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission needed"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error"
                        else -> "Voice error ($error)"
                    }
                    onFail(msg)
                }
                override fun onResults(results: Bundle?) {
                    listening.value = false
                    partial.value = ""
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) onFail("Nothing heard") else onText(t)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (bn) "bn-BD" else "en-US")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            r.startListening(i)
            listening.value = true
        }
    }

    fun stopListening() {
        main.post { destroyRecognizer() }
    }

    fun speak(text: String, bn: Boolean, after: () -> Unit = {}) {
        main.post {
            val t = tts
            if (t == null || !ttsReady) {
                ttsIssue.value = "Text-to-speech engine is not ready"
                after()
                return@post
            }
            val res = t.setLanguage(if (bn) Locale("bn", "BD") else Locale.US)
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsIssue.value = if (bn) "এই ফোনে বাংলা ভয়েস ইনস্টল নেই (Settings > Text-to-speech)" else "English voice is not installed"
                after()
                return@post
            }
            ttsIssue.value = null
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { speaking.value = true }
                override fun onDone(utteranceId: String?) {
                    speaking.value = false
                    main.post { after() }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    speaking.value = false
                    main.post { after() }
                }
            })
            t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "rahat")
        }
    }

    fun stopSpeaking() {
        main.post {
            tts?.stop()
            speaking.value = false
        }
    }

    fun shutdown() {
        main.post {
            destroyRecognizer()
            tts?.shutdown()
        }
    }
}
